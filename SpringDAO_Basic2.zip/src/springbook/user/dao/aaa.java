package springbook.user.dao;

import java.sql.Connection;
import java.sql.SQLException;

public class aaa extends UserDao{
	@Override
	protected Connection getConnection() throws ClassNotFoundException, SQLException {
		
		return null;
	}
}
