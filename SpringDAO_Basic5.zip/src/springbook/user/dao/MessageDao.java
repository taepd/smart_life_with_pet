package springbook.user.dao;

//게시판 관련 (CRUD)
public class MessageDao {

}
