package DI;

public class Program {

	public static void main(String[] args) {
		NewRecordView view = new NewRecordView(50, 60, 70);
		
		//무조건 생성자가 생성되서 new NewRecord생성
		view.print();
		

	}

}
