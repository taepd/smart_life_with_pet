package DI3;

import java.util.Scanner;

public class NewRecordView implements RecordVIew{
	//점수 출력하는 클래스
	private NewRecord record;//member field -> getter setter 생성 가능 그런데 여기서는 setter만 만들어 보자
	
	//1.생성자를 통해서 필요한 객체를 생성 or 주입 -> DI패키지에서 작업한것
	//2.함수 (setter)를 통해서 필요한 객체를 주입받을 수 있다. -> DI2
	//3.Interface를 활용(다형성)
	
	
	@Override
	public void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("kor");
		record.setKor(sc.nextInt());
		
		System.out.println("eng");
		record.setEng(sc.nextInt());
		
		System.out.println("math");
		record.setMath(sc.nextInt());
		
	}
	
	@Override
	public void print() {
		System.out.println(record.total() + " / " + record.avg());
	}
	
	//record의 setter 함수
	public void setRecord(Record record) {// parameter의 타입을 interface로 바꾸면 된다.(부모타입으로)
		//함수의 parameter를 통해서 NewRecord 객체의 주소값을 받아 준다.
		this.record = (NewRecord)record;
	}
    
	
}
