package DI3;

public interface Record {
	int total();
	float avg();
}
