package DI3;

public interface RecordVIew {
	void print();
	void input();
}
