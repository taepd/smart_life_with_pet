package Spring_DI4_2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Program {

	public static void main(String[] args) {
		//NewRecordView view = new NewRecordView();
		
		
		//필요에 의해 생성자를 만들 수 있다. 
		
		
		//NewRecord record = new NewRecord();
		//view.setRecord(record);//주입
		//view.input();		
		//view.print();
		
		

		
		
		
		//1.**SpringFramework가 제공하는 컨테이너가 생성되어야 하며(spring의 메모리가 생성되어야 한다.) 이 메모리를 IOC 컨테이너라고 한다.
		//2.만들어진 컨테이너(메모리)에 [필요한 객체를 넣고 조립하는 작업] >> XML파일에서 작업
		
		ApplicationContext context = new ClassPathXmlApplicationContext("DIConfig.xml");
		//이 한줄의 코드는 >> 컨테이너 만들고 >> xml파일을read하고 >> 컨테이너 객체를 생성하고 조립하는 것을 다 하는 것.
		
		//이제 레고 박스와 블럭이 만들어 진것. 
		//필요에 따라 박스에서 레고 블럭을 가지고 와서 놀면 된다.
		
		RecordVIew view = (RecordVIew)context.getBean("view");
		view.input();
		view.print();
		
		//Caused by : java.lang....
		//springframework의 jar가 다른 클래스를 의존하는 것
		
		
	}

}
