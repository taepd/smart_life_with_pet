package Spring_DI4_2;

public interface Record {
	int total();
	float avg();
}
