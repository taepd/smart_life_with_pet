package Spring_DI4_2;

public interface RecordVIew {
	void print();
	void input();
}
